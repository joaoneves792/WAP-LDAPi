<?php
/*
 * @file    : wap.php
 * @created : Apr 28, 2014
 * @author  : Ibéria Medeiros <ibemed at gmail.com>
 * @version : v1.0
 * @license : GNU Public License v2.0 http://www.gnu.org/licenses/gpl-2.0.html
 * @desc    : PHP WAP include file.
 */
 
	include('wap_XSS.php');
	include('wap_CodeInjection.php');
?>

