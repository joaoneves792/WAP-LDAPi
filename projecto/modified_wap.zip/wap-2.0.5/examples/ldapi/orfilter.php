<?php
$type = $_GET["type"];

$orfilter = "(|(type=".$type.")(type=printer))";

?>
