<?php

echo(
	"
	<form action=\"registo.php\" method=\"get\">
		<p><input type=\"submit\" value=\"Início\" /></p>
	</form>

	<form action=\"open.php\" method=\"post\">
		<p><input type=\"submit\" value=\"Ver os meus leilões\" /></p>
	</form>
	
	<form action=\"escolherData.php\" method=\"post\">
		<p><input type=\"submit\" value=\"Inscrição em leilões por dia\" /></p>
	</form>

	<form action=\"logout.php\" method=\"post\">
		<p><input type=\"submit\" value=\"Logout\"/></p>
	</form>"
	);


?>